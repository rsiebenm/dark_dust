Place the file winclip.dll in the main IDL directory.
This is normally C:\RSI\IDL5.5.

Place the *.wav files anywhere in your IDL path,
or in the Windows Media directory with other sound
files. This is normally C:\WINNT\MEDIA on Windows 2000
machines.

Place the bell.pro file somewhere in your IDL path.

Once the files are in place, type "BELL" at the IDL prompt.